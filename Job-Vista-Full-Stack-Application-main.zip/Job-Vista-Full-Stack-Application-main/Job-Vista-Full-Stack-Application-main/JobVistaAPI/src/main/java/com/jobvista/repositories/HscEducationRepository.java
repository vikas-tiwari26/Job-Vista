package com.jobvista.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jobvista.entities.HscEducation;

public interface HscEducationRepository extends JpaRepository<HscEducation, Integer> {

}
