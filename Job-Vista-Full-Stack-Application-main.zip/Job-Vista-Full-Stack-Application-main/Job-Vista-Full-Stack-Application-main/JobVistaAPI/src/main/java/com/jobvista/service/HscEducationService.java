package com.jobvista.service;

public interface HscEducationService {

}
