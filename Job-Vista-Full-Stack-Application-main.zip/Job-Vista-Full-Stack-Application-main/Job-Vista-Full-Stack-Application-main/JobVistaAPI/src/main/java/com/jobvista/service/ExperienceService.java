package com.jobvista.service;

public interface ExperienceService {

}
